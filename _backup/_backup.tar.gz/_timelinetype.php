<?php
require_once ('database.php');


class TimelineType extends DBO{

	protected static $tableName="timeline_type";
	protected static $tableFields=array('id', 'title');
	public $id;
	public $title;
	
	
	public static function create($data = array()){
		global $mydb;
		$timestamp = time();
		$sql = "INSERT INTO ". self::$tableName ." (`title`) VALUES (?)";
		return ($mydb->execute($sql, $data)) ? true: false;
	}
	
	Public static function updateByID($id, $data = array()){
		global $mydb;
		$sql = "UPDATE ". self::$tableName ." SET `title`=? WHERE `id` = ?";
		array_push($data, $id);
		return ($mydb->execute($sql, $data)) ? true: false;
	}

} // end of : class timelineType
$timelineType=new TimelineType();

?>