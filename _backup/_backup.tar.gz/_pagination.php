<?php

$currentFile = currentfile();

//pagination variable preparation
$page= !empty($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage=1;
$total=USER::countAll();
$pagination = new pagination($page, $perPage , $total);


 // Ths 2 lines find all objects and show them
$users = User::findAllPagination($perPage, $pagination->offset());
echo showAll($users, $columns);


// Here is the pagination
echo"<nav><ul class='pagination'>";

if ($pagination->totalPage () > 1) {

	if (! $pagination->hasPerviousPage ()) {
		echo "<li class='disabled'><a href='#' aria-label='Previous'><span aria-hidden='true'>&laquo</span></a></li>";
	} else {
		$link = $currentFile . "?page=" . $pagination->perviousPage ();
		echo "<li><a href=\"$link\" aria-label='Previous'><span aria-hidden='true'>&laquo</span></a></li>";
	}

	for($i = 1; $i <= $pagination->totalPage (); $i ++) {
		$link = $currentFile . "?page=" . $i;
		if ($i == $page) {
			echo "<li class='active'><a href=\"$link\">$i <span class='sr-only'>(current)</span></a></li>";
		} else {
			echo "<li><a href=\"$link\">$i</a></li>";
		}
	}

	if (! $pagination->hasNextPage ()) {
		echo "<li class='disabled'><a href='#' aria-label='Next'><span aria-hidden='true'>&raquo</span></a></li>";
	} else {
		$link = $currentFile . "?page=" . $pagination->nextPage ();
		echo "<li><a href=\"$link\" aria-label='Next'><span aria-hidden='true'>&raquo</span></a></li>";
	}
}

echo "</ul></nav>";




?>
