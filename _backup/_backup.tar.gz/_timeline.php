<?php
require_once ('database.php');


class Timeline extends DBO{

	protected static $tableName="timeline";
	protected static $tableFields=array('id', 'title', 'detail', 'type', 'event_date', 'date');
	public $id;
	public $title;
	public $detail;
	public $type;
	public $event_date;
	public $date;
	
	public static function create($data = array()){
		global $mydb;
		$timestamp = time();
		$sql = "INSERT INTO ". self::$tableName ." (`title`, `detail`, `type`, `event_date`,`date`) VALUES (?, ?, ?, ?, $timestamp)";
		return ($mydb->execute($sql, $data)) ? true: false;
	}

	/*
	public static function findUsername($username){
		global $mydb;
		$sql="SELECT * FROM ". self::$tableName. " WHERE (`username` = ?)";
		$parameter = array($username);
		return $mydb->execute($sql, $parameter);
	}
	*/
	
	Public static function updateByID($id, $data = array()){
		global $mydb;
		$sql = "UPDATE ". self::$tableName ." SET `title`=?,`detail`=?,`type`=?,`event_date`=?,`date`=? WHERE `id` = ?";
		array_push($data, $id);
		return ($mydb->execute($sql, $data)) ? true: false;
	}

} // end of : class timeline
$timeline=new Timeline();

?>